# VaxPlan: Enterprise Technical User & Administrator Documentation
*A Comprehensive Guide for Frontline Health Planners, District Managers, and National Administrators*

---

## 1. System Introduction & Architecture

VaxPlan is a **geo-enabled, offline-first, multi-tenant health microplanning platform** designed to optimize immunization service delivery, eliminate zero-dose clusters, and enforce logistics and financial accountability at the last mile. 

The application is structured to serve multiple countries (tenants) securely on a single, shared deployment, using a three-tier architecture:

```
                  ┌──────────────────────────────┐
                  │      Client Applications     │
                  │   (Capacitor / Electron /    │
                  │       Workbox PWA)           │
                  └──────────────┬───────────────┘
                                 │ HTTPS REST APIs / JSON
                                 ▼
                  ┌──────────────────────────────┐
                  │      Express Application     │
                  │       (Drizzle ORM)          │
                  └──────────────┬───────────────┘
                                 │ Secure Transaction SQL
                                 ▼
                  ┌──────────────────────────────┐
                  │    PostgreSQL + PostGIS      │
                  │   (Row-Level Security RLS)   │
                  └──────────────────────────────┘
```

### 1.1 Target Deployments

* **Frontline Field Workers (Android Tablet/Phone):** Runs as a native Android APK wrapped using **Capacitor**. Features local offline data entry, GPS coordinate recording, and background syncing.
* **District/County Health Offices (Windows Desktop):** Runs as an **Electron** wrapper installer (`.exe`). Provides a native Windows frame with desktop tray alerts, deep-linking sync capabilities, and local database mirrors.
* **National/Provincial Planners (Web Portal):** Deploys as a modern **Progressive Web App (PWA)** using Vite and Workbox Service Workers, caching maps and asset shells for zero-install access.

---

## 2. Multi-Tenant Sovereign Administration

VaxPlan allows multiple sovereign Ministries of Health to share a single hosting environment while maintaining absolute data separation.

### 2.1 Postgres Row-Level Security (RLS)
Sovereignty is enforced directly in the database. Every domain table (such as `facilities`, `users`, `sessionPlans`, and `clientLogbooks`) contains a `tenant_id` column. A PostgreSQL RLS policy filters all incoming queries dynamically:
```sql
ALTER TABLE facilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON facilities
  USING (tenant_id = current_setting('app.tenant_id')::varchar);
```
The application server dynamically sets `app.tenant_id` at the start of every database transaction based on the validated user session, preventing any cross-tenant data leaks.

### 2.2 Per-Tenant Settings Config (`tenants.settings`)
The platform adaptively adjusts its UI layout, naming labels, default coordinates, and metrics from a centralized JSONB configuration field:
* **`adminLevelLabels`:** Configures custom hierarchy names (e.g., Ward vs. Payam/Boma).
* **`demographics`:** Sets national birth and cohort target ratios.
* **`mapCenter` & `mapZoom`:** Sets default Leaflet center coordinates.
* **`currency` & `currencySymbol`:** Localizes financial per-diem and fuel dashboards.
* **`epiSchedule`:** Configures default antigens and age doses.

---

## 3. Geographically Scoped Governance & Approvals

VaxPlan enforces a strict role-based access control system mapped to the Ministry of Health's geographic hierarchy.

### 3.1 Hierarchical Roles & Scopes

| Role | Geographic Access Scope | Primary Actions |
| :--- | :--- | :--- |
| **Facility Clerk** | Facility level | Logs immunizations in the Client Logbook, tracks local session checklist progress. |
| **Facility In-Charge** | Parent Facility + Villages | Builds routine microplans, manages local fridge inventories, and submits plans. |
| **District Manager** | District level (all facilities) | Reviews and approves facility microplans, manages district fuel and travel budgets. |
| **Provincial Coordinator**| Province level (all districts) | Reviews provincial coverage dashboards, coordinates cold chain equipment distribution. |
| **GIS Specialist** | National / Tenant level | Manages administrative shapefile boundaries, maps GIS overlays, and imports MFL registries. |
| **National Admin** | National / Tenant level | Oversees tenant integrations, configures SSO parameters, and manages platform audits. |

### 3.2 Decentralized Hierarchical Signups
To remove administrative overhead from central IT departments, user approvals are handled directly by supervisors located one tier above the requested role:

```
               [ Request: Clerk ] ──────► Approved by: Facility In-Charge
               [ Request: In-Charge ] ──► Approved by: District Manager
               [ Request: Manager ] ────► Approved by: Provincial Coordinator
               [ Request: Coordinator ]► Approved by: National Admin
```

#### The Registration & Validation Flow:
1. An unauthenticated user visits `/signup`, enters their email (must match the tenant's validated email domain), and fills out cascading dropdowns to pick their Province, District, and Health Facility.
2. The system registers a record in `signup_requests` with a `pending` status.
3. The system dynamically computes the authorized approver (e.g., finding the `district_manager` whose `districtId` matches the requested facility's parent district).
4. The approver receives a notification in their **Pending Approvals Inbox**. They review the justification text, click "Approve," and the user's role is activated.
5. On the user's first login via the tenant's SSO identity provider (OIDC/SAML), their authentication token is securely bound to their database record.

---

## 4. Interactive GIS Microplanning Workflow

VaxPlan is a map-driven workspace built on top of Leaflet and Turf.js. It bridges aggregate demographic models with actual geographic structure counts.

```
┌───────────────────────────────────────────────────────────┐
│ [Global Country Switcher ▼]            [ Layer Toggles ]  │
│ ┌────────────────────────┐             [x] Facilities     │
│ │   ● Mukobeko Clinic    │             [x] Catchments     │
│ │                        │             [x] GRID3 Bldgs    │
│ │   ▲ Village (HTR)      │             [x] WorldPop Grid  │
│ │                        │             └──────────────────┘
│ │   ░░ Density Heatmap   │             [ Checklist ]      │
│ │      (GeoTIFF Grid)    │             [x] Static Session │
│ │                        │             [/] Outreach Geof  │
│ └────────────────────────┘             [ ] Mobile Corridor│
└───────────────────────────────────────────────────────────┘
```

### 4.1 Live GIS Overlays
Planners can toggle standard and proprietary GIS layers from the top-right overlay manager:
1. **GRID3 Settlement Footprints:** Renders high-fidelity building footprint polygons (diamond-clustered mock structures around active facilities) to spot exact house patterns in remote areas.
2. **WorldPop Density Heatmaps:** Renders high-resolution 100m gridded population density GeoTIFFs directly on the map context, revealing target concentrations.
3. **Administrative Boundaries:** Renders shapefiles for provinces, districts, and local wards dynamically.
4. **Active Centroid Switcher:** Enables planners to dynamically switch targets (e.g., **Zambia**, **South Sudan**, or **Papua New Guinea**). The map instantly pans and centers on the selected country's centroid.

### 4.2 Multi-Source Population Consensus Panel
When creating a derived session plan or clicking a coordinate pixel, VaxPlan triggers a **Denominator Consensus Panel** side-by-side:
* **WorldPop Gridded Sum:** Calculates the mathematical sum of all population raster cells enclosed within the geofenced area.
* **Registry Census Sum:** Sums the bottom-up village populations whose coordinates fall inside the boundary.
* **GRID3 Struct Occupancy:** Counts building footprint structures within the geofence and multiplies them by local average household density ratios.
* **Denominator Calibration Override:** Planners can review these three estimates and click a single button to adopt the most accurate estimate, overriding old census baselines.

### 4.3 Drawing Outreach Polygons & Mobile Polyline Corridors
* **Outreach Geofencing:** Planners use drawing tools to plot closed polygon geofences representing an outreach team's physical walk area.
* **Mobile Polyline Corridors:** Planners plot linear polyline corridors representing mobile health vans or boat dispatches. The system automatically applies a **500m buffer** corridor on either side of the polyline.
* **Client-Side High-Performance Intersection:** To operate in offline environments without external GIS servers, VaxPlan runs custom ray-casting algorithms to determine point-in-polygon inclusions for villages and population grid coordinates in milliseconds.

### 4.4 The Floating Checklist Sidebar
* **Spatial Tracking:** A Checklist Sidebar floats on the right, shifting automatically to prevent overlapping standard panels.
* **Interactive Status badges:**
  - *Planned:* Rendered as a gold-amber dashed geofence vector with a gold badge.
  - *Achieved:* Rendered as a solid emerald-green geofence vector with completed checklist strikethroughs, updated immediately in the database.
* **Map Centering:** Clicking any session card instantly pans the map to its geofenced centroid bounds.

---

## 5. Cold Chain & Logistics Management

Planners must ensure vaccine and budget availability before locking microplans.

### 5.1 Vaccine Requirement Calculator
* **Target Cohort Calculation:** Auto-estimates target cohorts based on per-tenant demographic ratios.
* **Wastage Rate Math:** Calculates required doses and vials based on the antigen type and local wastage factors:
  $$\text{Required Vials} = \text{ceil}\left( \frac{\text{Target Population} \times \text{Doses Required}}{\text{Antigen Doses per Vial} \times (1 - \text{Wastage Rate})} \right)$$
* **Equipment Verification:** Cross-references required cold chain volumes against the facility's active refrigerator storage capacity (MFL registry metrics) to prevent stock spoilage.
* **VVM Status Tracking:** Tracks Vaccine Vial Monitor (VVM) stages (Stage 1 to 4) inside stock ledgers, warning health workers if a vaccine vial's heat threshold is exceeded.

### 5.2 Financial per Diem & Fuel Controls
To prevent administrative inflation and budget leakage, costs are bound directly to mapped outreach routes:
* **Spatial Allowance Estimator:** Calculates per diems based on travel time and team sizes.
* **Fuel Rate Standardization:** Links travel distances (computed along mapped linear vectors) to vehicle fuel consumption factors per kilometer.
* **Social Mobilization Alignment:** Maps communication campaigns, Church announcements, and local mobilizer costs alongside scheduled sessions to maximize turnout.

---

## 6. Offline-First Synchronizations

VaxPlan's core architecture is offline-first. The app relies on a local Dexie/IndexedDB database that mirrors Postgres tables.

```
                  [ Offline User Actions ]
                             │
                             ▼
                 [ Local IndexedDB Mirror ]
                             │  fails (offline) / succeeds (online)
                             ▼
                [ Local Outbox Mutation Queue ]
                             │
                             │  when network returns ONLINE
                             ▼
                  [ VaxPlan Sync Engine ]
                             │  POST /api/sync/batch (Bulk push)
                             ▼
                  [ PostgreSQL Server DB ]
```

### 6.1 Caching Strategy (Workbox Service Worker)

| Asset Class | Caching Strategy | Retention / Target |
| :--- | :--- | :--- |
| **App Shell (HTML/JS/CSS)** | `CacheFirst` | Indefinite (busted via build hashes) |
| **Standard API (`/api/*` GET)** | `NetworkFirst` | 5-second timeout, falls back to cache |
| **Map Tiles (OSM / Carto)** | `CacheFirst` | 30 days, maximum 1,500 tiles cached |
| **Sync Endpoint (`/api/sync/*`)** | `NetworkOnly` | Always live |

### 6.2 Network-Aware staleTime Tuning
To save battery and data charges on cellular plans, VaxPlan adjusts React Query caching dynamically:
* **Online:** Sets `staleTime: 0`, forcing live updates.
* **Offline:** Sets `staleTime` to a configurable duration read from `localStorage` (1, 2, 4, 8, 12, or 24 hours, defaulting to 2 hours). It serves cached IndexedDB data and prevents unnecessary network requests.
* **Configuration UI:** Health workers can configure this cache interval directly inside the **Offline Mode Card** in Settings.

### 6.3 Conflict Resolution Log
If two offline devices modify the same record, VaxPlan applies a **Last-Writer-Wins (LWW)** policy. The losing edit is archived in the `conflictLog` table. Administrators can review and restore overridden values through the system audit dashboard.

---

## 7. Standardized HIS Interoperability

VaxPlan connects to national health portals to prevent data silos.

### 7.1 DHIS2 Aggregate Gateway
* **The Route:** `POST /api/sync/his/dhis2`
* **Workflow:** Translates VaxPlan monthly immunization summaries into standard DHIS2 JSON payload bundles containing aggregate values, organization units, and data element UIDs.
* **Configuration:** District Managers set integration tokens in Tenant settings. Planners link individual facility columns to unique DHIS2 organization unit IDs.

### 7.2 HL7 FHIR R4 Interface
* **The Route:** `/api/fhir/*`
* **Workflow:** Acts as a standard FHIR client and server, mapping VaxPlan vaccination logs to standard FHIR `Immunization`, `Patient`, and `Location` resources. This enables seamless connection with OpenMRS and generic EHR registers.

---

## 8. Deployment & Onboarding Blueprints

### 8.1 Onboarding Checklist (GIS Specialist / National Admin)
1. **Tenant Provisioning:** Run the automated tenant creation script:
   ```powershell
   npm run onboard-tenant
   ```
   Follow prompts to set the country name, ISO-3166 code (e.g. `ZMB` or `SSD`), currency, default coordinates, and SSO credentials.
2. **Database Push:** Apply current schema modifications:
   ```powershell
   npm run db:push
   ```
3. **Upload GeoJSON Boundaries:** Go to **Boundary Manager**, select the admin level, and upload the OCHA COD-AB boundary GeoJSON file.
4. **Import Master Facility List (MFL):** Upload the national clinic CSV file (coordinates, HMIS code, fridge status).
5. **Seed Census Demographics:** Seed local population databases using the tenant's administrative hierarchy.
6. **Deploy Native Builds:**
   * Build the Android APK: `npm run build:android`
   * Build the Windows Installer: `npm run build:windows`

### 8.2 Common Troubleshooting Guide

#### 1. "GRID3 Settlement Footprints are not rendering on the map."
* **Cause:** The GRID3 dataset is localized or geographically restricted.
* **Solution:** Verify that the viewport matches seeded coordinates. If testing in central Zambia, ensure `add-mock-settlements.ts` has been run to generate diamond structural mock footprints around the MFL locations.

#### 2. "Device outbox is failing to sync upon network reconnection."
* **Cause:** Authentication session expired during offline operations, or the `tenantId` mismatch between IndexedDB payloads and the server HttpOnly session cookie.
* **Solution:** Navigate to the login screen, re-authenticate to renew the session cookie, and click the **Sync Now** button in the **Offline Mode Status Banner**.

#### 3. "TypeError: georaster is not a function."
* **Cause:** ESM/CJS default-export bundling mismatch during Vite dynamic builds.
* **Solution:** Ensure the parser import in `MapView.tsx` uses the default-export wrapper check:
  ```typescript
  const parseFn = (parseGeoraster as any).default || parseGeoraster;
  ```
