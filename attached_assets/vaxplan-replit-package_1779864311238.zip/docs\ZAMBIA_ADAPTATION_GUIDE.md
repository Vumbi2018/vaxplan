# Building a Zambia Health Microplanning Application

A step-by-step guide to adapt this Papua New Guinea (PNG) GIS microplanning system for **Zambia's Ministry of Health**, with a focus on the multi-source **Population Data Management** feature.

---

## 1. Overview

This application supports vaccination microplanning by managing health facilities, villages, population data, session plans, vaccine requirements, and approvals. The PNG version is built around PNG's administrative hierarchy, NSO census, and HMIS structure. To adapt it for Zambia, you will mainly:

1. Replace administrative hierarchy data (regions/provinces/districts).
2. Replace data sources (NSO → ZamStats; HMIS → SmartCare/HMIS Zambia).
3. Replace seed census numbers with Zambia 2022 Census of Population and Housing.
4. Adjust user roles to match Zambia's Ministry of Health structure.

The codebase is generic enough that the schema and UI can stay almost identical — most changes are configuration and seed data.

---

## 2. Tech Stack (Unchanged)

| Layer | Technology |
|------|------------|
| Frontend | React 18 + TypeScript, Wouter, TanStack Query v5, shadcn/ui, Tailwind CSS |
| Maps | Leaflet + React-Leaflet, Turf.js |
| Forms | React Hook Form + Zod |
| Backend | Node.js + Express (TypeScript ESM) |
| Database | PostgreSQL + Drizzle ORM |
| Auth | Replit OpenID Connect + Passport.js, sessions in `connect-pg-simple` |
| Export | XLSX (SheetJS) |

Run with `npm run dev` (single port 5000 for API + Vite).

---

## 3. Administrative Hierarchy: PNG vs Zambia

| Level | PNG | Zambia |
|------|------|--------|
| 1 | Region (4: Southern, Highlands, Momase, Islands) | **Region** (optional grouping; Zambia does not officially use regions, so you can either drop this level or define logical groupings such as *Northern, Central, Southern, Eastern, Western, Copperbelt cluster*) |
| 2 | Province (22) | **Province** (10: Central, Copperbelt, Eastern, Luapula, Lusaka, Muchinga, Northern, North-Western, Southern, Western) |
| 3 | District (96) | **District** (~116 districts as of 2024) |
| 4 | LLG (Local Level Government) | **Constituency** or **Ward** (Zambia uses constituencies → wards) |
| 5 | Village/Settlement | **Village / Catchment Area / CHW Zone** |

### Recommended action

- Keep the existing `regions`, `provinces`, `districts`, `llgs`, `villages` tables unchanged.
- Rename `llgs` table semantically to represent **Wards** (or keep the table name and just relabel in the UI).
- If you don't need a region grouping, allow `provinces.regionId` to be `NULL` and hide the Region filter in the UI.

---

## 4. Schema Changes (`shared/schema.ts`)

The schema is already mostly Zambia-ready. The required edits are minimal.

### 4.1 Population source enum

Replace PNG-specific data sources with Zambia equivalents:

```ts
export const populationSourceEnum = pgEnum("population_source", [
  "zamstats",          // Zambia Statistics Agency (replaces "nso")
  "hmis",              // SmartCare / DHIS2 HMIS Zambia
  "worldpop",          // WorldPop gridded estimates
  "survey",            // ZDHS (Zambia Demographic & Health Survey) or MIS
  "community_census",  // Community Health Worker enumeration
]);
```

> Run `npm run db:push` after editing the enum. If Drizzle prompts about data loss because of an enum value change, choose the "create new + migrate" path or temporarily allow `--force` only on a fresh DB.

### 4.2 User roles

Map PNG roles to Zambia's MOH structure:

| PNG role | Zambia equivalent | Suggested enum value |
|----------|-------------------|----------------------|
| facility_clerk | Facility Data Clerk | `facility_clerk` |
| facility_in_charge | Health Centre In-Charge | `facility_in_charge` |
| district_manager | District Health Director (DHD) | `district_manager` |
| provincial_coordinator | Provincial Health Director (PHD) | `provincial_coordinator` |
| national_admin | MOH HQ EPI Manager | `national_admin` |
| gis_specialist | MOH GIS / M&E Officer | `gis_specialist` |

Enum values can stay the same; just relabel in the UI (`client/src/lib/permissions.ts` and any role label maps).

### 4.3 Facility table fields

Zambia's HMIS unique identifier is the **HMIS Code (e.g. `1010xx`)** issued by MOH. The existing `facilities.hmisCode` field works as-is. Consider adding:

- `facilityLevel` (Health Post, Rural Health Centre, Urban Health Centre, 1st Level Hospital, 2nd Level, 3rd Level, Specialist).
- `ownership` (Government, Faith-Based / CHAZ, Private, Mine, Military).

Both can be added as `varchar` columns alongside the existing `facilityType` and `agencyName` fields with no other code changes.

### 4.4 No other schema changes required

`populationData`, `sessionPlans`, `budgetItems`, `vaccineRequirements`, `mobilizationActivities`, `approvalRequests`, `auditLogs`, and `htrScores` are all hierarchy-agnostic and can be reused as-is.

---

## 5. Seed Data for Zambia

Create `server/seed-zambia.ts` (mirror of `server/seed-census.ts`) and run it after `npm run db:push`.

### 5.1 Provinces (10)

```ts
const ZAMBIA_PROVINCES = [
  { name: "Central",       code: "CEN" },
  { name: "Copperbelt",    code: "COP" },
  { name: "Eastern",       code: "EAS" },
  { name: "Luapula",       code: "LUA" },
  { name: "Lusaka",        code: "LSK" },
  { name: "Muchinga",      code: "MUC" },
  { name: "Northern",      code: "NOR" },
  { name: "North-Western", code: "NWP" },
  { name: "Southern",      code: "SOU" },
  { name: "Western",       code: "WES" },
];
```

### 5.2 ZamStats 2022 Census population (province totals)

These are the official 2022 Census of Population and Housing figures from the Zambia Statistics Agency. Use them as the seed for `source = "zamstats"`, `year = 2022`.

| Province | 2022 Population | Annual Growth Rate (2010–2022) |
|----------|----------------:|-------------------------------:|
| Central       | 2,575,217  | 2.9% |
| Copperbelt    | 2,669,635  | 1.7% |
| Eastern       | 2,366,036  | 2.0% |
| Luapula       | 1,519,283  | 2.7% |
| Lusaka        | 3,308,438  | 3.6% |
| Muchinga      | 1,152,288  | 3.4% |
| Northern      | 1,545,294  | 2.6% |
| North-Western | 1,005,564  | 3.1% |
| Southern      | 2,116,506  | 2.8% |
| Western       | 1,486,853  | 2.0% |
| **National**  | **19,610,769** | **2.8%** |

> Always double-check current numbers against the latest ZamStats publication ([zamstats.gov.zm](https://www.zamstats.gov.zm)).

### 5.3 Demographic ratios

Replace the PNG hard-coded ratios in `seed-census.ts` with Zambia values from ZDHS 2018:

```ts
malePopulation:    Math.round(total * 0.493),
femalePopulation:  Math.round(total * 0.507),
under1Population:  Math.round(total * 0.034),
under5Population:  Math.round(total * 0.165),
pregnantWomen:     Math.round(total * 0.040),
```

### 5.4 Districts seeding

Create a CSV (or JSON) of all ~116 Zambian districts with their parent province, then loop-insert into `districts`. ZamStats publishes the official list. Recommended structure:

```ts
const ZAMBIA_DISTRICTS = [
  { name: "Lusaka",  code: "LSK01", province: "Lusaka" },
  { name: "Chongwe", code: "LSK02", province: "Lusaka" },
  // ... ~114 more
];
```

---

## 6. Population Data Management Feature (Reference Implementation)

The feature this guide focuses on lives in:

- `client/src/pages/Population.tsx` — page with 5 tabs (one per source) + cascading filters + table + Excel export
- `client/src/components/PopulationDialog.tsx` — create/edit form with Zod validation
- `client/src/components/DeleteConfirmDialog.tsx` — confirmation dialog
- `client/src/lib/permissions.ts` — role gates (`canCreateData`, `canDeleteData`)
- `server/routes.ts` — `/api/population` REST endpoints
- `server/storage.ts` — `IStorage` CRUD methods for population data
- `server/seed-census.ts` — seeding script (replicate as `seed-zambia.ts`)

### 6.1 Behaviour to preserve when adapting

1. **Five tabs** — one per `populationSourceEnum` value. Update tab labels to: `ZamStats Census`, `HMIS / SmartCare`, `WorldPop`, `Survey (ZDHS/MIS)`, `Community Census`.
2. **Cascading filters** — Region → Province → District → Year. If you drop the Region level, start the cascade at Province.
3. **Role-based actions** — only `facility_in_charge` and above can create/edit; only `district_manager` and above can delete. This is enforced in `client/src/lib/permissions.ts` and re-checked server-side in `server/routes.ts`.
4. **Cache invalidation** — on mutation, invalidate every query whose key starts with `/api/population` using a `predicate`:
   ```ts
   queryClient.invalidateQueries({
     predicate: (q) => Array.isArray(q.queryKey) && q.queryKey[0] === '/api/population',
   });
   ```
5. **Excel export** — uses XLSX with one sheet per active filter set. Keep this; just relabel column headers.

### 6.2 UI label changes

| PNG label | Zambia label |
|-----------|--------------|
| NSO Census | ZamStats Census |
| LLG | Ward |
| HMIS | SmartCare / HMIS |
| Province (PNG name) | Province (Zambia name) |
| Hard-to-Reach (HTR) | Hard-to-Reach (HTR) — keep |

---

## 7. Step-by-Step Build Plan

Follow this order when starting a fresh Zambia project:

### Step 1 — Bootstrap
```bash
# Use the same template (Express + Vite + Drizzle + shadcn)
npm install
```
Set environment variables: `DATABASE_URL`, `SESSION_SECRET`, `ISSUER_URL`, `REPL_ID`.

### Step 2 — Schema
1. Copy `shared/schema.ts` from PNG project.
2. Edit `populationSourceEnum` to use `zamstats` (Section 4.1).
3. (Optional) Add `facilityLevel` and `ownership` columns to `facilities`.
4. Run `npm run db:push`.

### Step 3 — Seed administrative hierarchy
1. Create `server/seed-zambia-admin.ts` to insert 10 provinces and ~116 districts.
2. Run it once: `tsx server/seed-zambia-admin.ts`.

### Step 4 — Seed ZamStats census
1. Create `server/seed-zambia.ts` based on `server/seed-census.ts` using the 2022 Census numbers in Section 5.2.
2. Run it: `tsx server/seed-zambia.ts`.

### Step 5 — Storage + routes
Copy `server/storage.ts` and `server/routes.ts` from PNG. The CRUD layer is generic; no edits required besides making sure the role check matches Zambia roles (Section 4.2).

### Step 6 — Population page + dialogs
Copy:
- `client/src/pages/Population.tsx`
- `client/src/components/PopulationDialog.tsx`
- `client/src/components/DeleteConfirmDialog.tsx`
- `client/src/lib/permissions.ts`

Apply UI label changes in Section 6.2.

### Step 7 — Authentication
Use Replit OpenID Connect (already wired). After first login, manually `UPDATE users SET role = 'national_admin' WHERE email = 'you@moh.gov.zm';` for the seed admin.

### Step 8 — Facilities and villages
Import the **MOH Master Facility List (MFL)** for Zambia (CSV from MOH/CHAZ). Insert into `facilities` with `hmisCode` from MFL. For villages, the **CSO Enumeration Areas (EAs)** dataset can be used as a starting point.

### Step 9 — Maps
Replace PNG default map centre `[-6.0, 145.0]` with Zambia centre `[-13.13, 27.85]` and zoom level 6 in any Leaflet `MapContainer` initialisations.

### Step 10 — Branding
- Replace PNG flag/logo with Zambia MOH logo (drop file in `attached_assets/`).
- Update app title and `<meta>` description in `client/index.html`.
- Update `replit.md`.

---

## 8. Differences You Must Not Forget

1. **Vaccine schedule** — PNG and Zambia EPI schedules differ slightly. Update default vaccines in `vaccineRequirements` seed data to match Zambia's EPI: BCG, OPV (0,1,2,3), Penta (1,2,3), PCV (1,2,3), Rota (1,2), IPV, Measles-Rubella (1,2), HPV, TT/Td.
2. **Cold chain** — Zambia uses a tighter solar-direct-drive fridge programme; consider adding a `solarFridge` boolean to `facilities`.
3. **Currency** — Budget items are stored as decimals; just relabel currency to **ZMW (Zambian Kwacha)** in UI.
4. **Language** — Add Bemba/Nyanja/Tonga translation hooks if multi-language is required (not currently implemented in PNG version).
5. **Geography precision** — Zambia is land-locked, so the `transport_mode` enum value `boat` is rarely used (Lake Bangweulu, Tanganyika, Kariba and the Zambezi remain valid use cases — keep the enum value).

---

## 9. Permissions Logic (Reusable As-Is)

From `client/src/lib/permissions.ts`:

```ts
const roleHierarchy = {
  facility_clerk: 1,
  facility_in_charge: 2,
  district_manager: 3,
  provincial_coordinator: 4,
  national_admin: 5,
  gis_specialist: 5,
};

canCreateData = role >= facility_in_charge   // 2
canDeleteData = role >= district_manager     // 3
```

Server-side, every `POST/PATCH/DELETE /api/population/*` route must re-check `req.user.role` against the same hierarchy — never trust the client.

---

## 10. Validation Checklist Before Go-Live

- [ ] All 10 provinces seeded with correct ZamStats codes
- [ ] All districts seeded and linked to correct province
- [ ] 2022 census totals match published ZamStats figures
- [ ] First admin user upgraded to `national_admin`
- [ ] Province-level provincial coordinators can only see their own province's data (test with `provincial_coordinator` role)
- [ ] District managers can delete; facility in-charges cannot delete
- [ ] Excel export opens cleanly in Microsoft Excel and LibreOffice
- [ ] Map centre and default zoom show all of Zambia
- [ ] Cache invalidation works after create/edit/delete
- [ ] EPI vaccine schedule matches MOH 2024 guidelines

---

## 11. Useful References

- Zambia Statistics Agency — https://www.zamstats.gov.zm
- 2022 Census of Population and Housing — Preliminary & Final Reports
- Zambia DHIS2 / SmartCare — MOH HMIS portal
- Master Facility List (MFL) — MOH Zambia
- ZDHS 2018 — DHS Program (https://dhsprogram.com)
- WorldPop Zambia — https://www.worldpop.org

---

*Generated as a Zambia adaptation guide for the PNG GIS Microplanning Application. Replicate, adapt, and improve as Zambia MOH requirements evolve.*
