# Multitenant Architecture Plan

Turning the GIS Microplanning platform into a multitenant SaaS that any Ministry of Health can adopt.

---

## 1. Confirmed Decisions

| # | Decision | Choice |
|---|----------|--------|
| 1 | Target tenant count (year 1–2) | 5+ countries |
| 2 | Data residency required? | No |
| 3 | Tenant resolution | Auto-resolve from logged-in user |
| 4 | User can belong to multiple tenants? | No — strictly one user, one tenant |
| 5 | Platform-level super-admin above tenants? | No — each tenant is fully sovereign |
| 6 | Authentication | Each tenant brings their own SSO (OIDC / SAML / AD) |

These choices lead to the simplest viable design: **shared database, shared schema, `tenant_id` column on every tenant-owned table, BYO-SSO per tenant.**

---

## 2. Target Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Tenant A SSO    Tenant B SSO    Tenant C SSO   ...     │
│  (Zambia AD)     (PNG OIDC)      (Kenya Okta)           │
└────────┬──────────────┬──────────────┬──────────────────┘
         │ OIDC/SAML    │              │
         ▼              ▼              ▼
┌─────────────────────────────────────────────────────────┐
│         Auth Layer  (passport-openidconnect /           │
│                     passport-saml dispatcher)           │
│         → resolves user.email → users.tenantId          │
└─────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│  Express middleware: requireTenant(req)                 │
│  → attaches req.tenantId from session                   │
└─────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│  Storage layer: every method takes tenantId             │
│  Postgres: RLS policies as defense in depth             │
└─────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│  Single Postgres database, single schema                │
│  Every domain table has tenant_id NOT NULL              │
└─────────────────────────────────────────────────────────┘
```

---

## 3. Schema Changes

### 3.1 New tables

```ts
// shared/schema.ts

export const tenantStatusEnum = pgEnum("tenant_status", [
  "trial",
  "active",
  "suspended",
  "archived",
]);

export const tenants = pgTable("tenants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),         // "Zambia Ministry of Health"
  code: varchar("code", { length: 10 }).notNull().unique(), // "ZMB"
  countryCode: varchar("country_code", { length: 3 }).notNull(), // ISO-3166-alpha-3
  status: tenantStatusEnum("status").default("trial").notNull(),
  settings: jsonb("settings").notNull().default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// One SSO config per tenant. A tenant may have several (AD + OIDC fallback).
export const tenantIdpConfigs = pgTable("tenant_idp_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
  protocol: varchar("protocol", { length: 20 }).notNull(),  // "oidc" | "saml"
  displayName: varchar("display_name", { length: 255 }).notNull(),
  // OIDC
  issuerUrl: varchar("issuer_url"),
  clientId: varchar("client_id"),
  clientSecretRef: varchar("client_secret_ref"),            // reference to secret store, never the value
  // SAML
  entryPoint: varchar("entry_point"),
  cert: text("cert"),
  // Common
  emailDomain: varchar("email_domain", { length: 255 }),    // "moh.gov.zm" → used to route login
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});
```

### 3.2 Per-tenant settings (`tenants.settings` jsonb shape)

```jsonc
{
  "currency": "ZMW",
  "currencySymbol": "K",
  "languages": ["en", "bem", "ny"],
  "defaultLanguage": "en",
  "mapCenter": [-13.13, 27.85],
  "mapZoom": 6,
  "skipRegionLevel": true,
  "adminLevelLabels": {
    "level2": "Province",
    "level3": "District",
    "level4": "Ward",
    "level5": "Village"
  },
  "populationSources": [
    { "code": "zamstats", "label": "ZamStats Census" },
    { "code": "hmis",     "label": "HMIS / SmartCare" },
    { "code": "worldpop", "label": "WorldPop" },
    { "code": "survey",   "label": "ZDHS / MIS" },
    { "code": "community_census", "label": "Community Census" }
  ],
  "epiSchedule": "ZMB_2024",
  "branding": {
    "logoUrl": "/tenants/zmb/logo.png",
    "primaryColor": "#005A33"
  },
  "fiscalYearStart": "01-01"
}
```

### 3.3 Add `tenantId` to every domain table

Tables that get a new `tenantId varchar NOT NULL REFERENCES tenants(id)` column **and** an index on `(tenantId, ...)`:

- `users`
- `regions`, `provinces`, `districts`, `llgs`, `villages`
- `facilities`
- `populationData`
- `sessionPlans`, `budgetItems`, `vaccineRequirements`, `mobilizationActivities`
- `approvalRequests`, `auditLogs`, `htrScores`

Tables that **do not** need `tenantId`:
- `sessions` (Replit auth session table — store `tenantId` inside the session payload instead)
- `tenants`, `tenantIdpConfigs` (the multitenant control plane itself)

### 3.4 Replace global enums with per-tenant lookup

`populationSourceEnum` is a Postgres enum — global. Convert it to a lookup table so each tenant can have its own:

```ts
export const populationSources = pgTable("population_sources", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  tenantId: varchar("tenant_id").notNull().references(() => tenants.id),
  code: varchar("code", { length: 50 }).notNull(),     // "zamstats" or "nso"
  label: varchar("label", { length: 255 }).notNull(),
  sortOrder: integer("sort_order").default(0),
}, (t) => [unique().on(t.tenantId, t.code)]);
```

Then `populationData.source` becomes `sourceId integer references population_sources(id)`.

> The same treatment may be useful for `transport_mode` and any other enums you want tenants to extend (not strictly required for v1).

---

## 4. Authentication Layer (BYO SSO)

### 4.1 Login flow

```
User visits /login
  → enters email
  → server looks up tenant_idp_configs WHERE email_domain = domain(email)
  → redirects to that tenant's IdP (OIDC authorize URL or SAML SSO URL)
  → IdP authenticates and redirects back to /auth/callback
  → server upserts users row (tenantId, email, role)
  → session cookie issued with { userId, tenantId }
```

### 4.2 Recommended libraries

- **OIDC tenants**: `openid-client` (modern, supports dynamic per-tenant config) — replaces `passport-openid-connect` from the current Replit Auth setup.
- **SAML tenants**: `@node-saml/passport-saml` with a `MultiSamlStrategy` so configs are loaded per request from `tenant_idp_configs`.
- **Secrets storage**: never put `clientSecret` or SAML private keys in the database in plaintext. Use environment variables or an external secret manager (AWS Secrets Manager, GCP Secret Manager, HashiCorp Vault). Store only a *reference* in `clientSecretRef`.

### 4.3 First-user bootstrap per tenant

When a tenant is onboarded, the operator runs a CLI that creates an initial `national_admin` user with a known email. The first time that email logs in via the tenant's SSO, the `users` row is updated with the SSO subject ID. Subsequent `national_admin`s are created from inside the app.

### 4.4 Logout

Use SSO Single Logout (SLO) where the IdP supports it; otherwise local session invalidation only.

---

## 5. Tenant Isolation: Defense in Depth

Three layers, all required:

### Layer 1 — Application code
Every storage method takes `tenantId` and includes it in `where`. Enforce via TypeScript:

```ts
interface TenantScoped { tenantId: string }

async getFacilities(ctx: TenantScoped, filters: FacilityFilters) {
  return db.select().from(facilities)
    .where(and(eq(facilities.tenantId, ctx.tenantId), ...filters));
}
```

Lint rule (custom ESLint or simple `rg` CI check): every reference to a tenant-scoped table in `server/storage.ts` must appear in a query that also references `tenantId`.

### Layer 2 — Express middleware
```ts
app.use(requireAuth);
app.use(requireTenant);   // sets req.tenantId from session, 401 if missing
app.use((req, _res, next) => { req.ctx = { tenantId: req.tenantId, userId: req.userId }; next(); });
```

Routes must always pass `req.ctx` into storage methods. Never pass `tenantId` from the client body.

### Layer 3 — Postgres Row-Level Security (RLS)
Backstop in case application code forgets a filter:

```sql
ALTER TABLE facilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON facilities
  USING (tenant_id = current_setting('app.tenant_id')::varchar);
```

The connection pool sets `app.tenant_id` per request (`SET LOCAL app.tenant_id = '...'`) inside a transaction. Drizzle supports this via a `db.transaction(...)` wrapper.

> RLS does not need to be perfect day one — Layer 1 + Layer 2 is enough for launch. Add RLS in Phase 4 hardening.

---

## 6. Roles (Per-Tenant)

The role enum stays exactly as it is. Each role is implicitly scoped to the user's tenant:

```
facility_clerk → facility_in_charge → district_manager → provincial_coordinator → national_admin
                                                                                ↘ gis_specialist
```

`national_admin` is the top of each tenant. There is no platform-wide super-admin role inside the app. Platform onboarding is done via a CLI script that runs against the database directly (Section 7).

---

## 7. Tenant Onboarding (CLI, not UI)

Because tenants are fully sovereign and there's no platform admin, tenant creation is an operator task, not a feature. Build a small `npm run onboard-tenant` script that:

1. Prompts for tenant name, code, country code.
2. Creates the `tenants` row.
3. Prompts for SSO type and config, writes `tenant_idp_configs`.
4. Imports the country's admin hierarchy from CSV (provinces, districts, wards).
5. Imports the Master Facility List from CSV.
6. Seeds census numbers from CSV.
7. Seeds `population_sources` lookup rows.
8. Creates the first `national_admin` user with a known email.
9. Prints next steps for the customer.

This script is the "Zambia adaptation guide" automated.

---

## 8. Migration Plan for Existing PNG Data

The current production data is single-tenant. To migrate without downtime issues:

1. **Add tenant tables** (`tenants`, `tenant_idp_configs`, `population_sources`).
2. **Insert PNG tenant**: `INSERT INTO tenants (code, name, country_code) VALUES ('PNG', 'PNG NDOH', 'PNG');`
3. **Add nullable `tenant_id`** to every domain table.
4. **Backfill**: `UPDATE facilities SET tenant_id = (SELECT id FROM tenants WHERE code='PNG');` — repeat for every table.
5. **Migrate `populationData.source`** enum → FK to new `population_sources` table.
6. **Make `tenant_id` NOT NULL** and add indexes.
7. **Drop old `populationSourceEnum`** type.
8. **Add RLS policies** (Phase 4).

All steps are reversible up to step 7. Run on a staging copy first.

---

## 9. Per-Tenant Concerns Checklist

- **File uploads / branding assets** → object storage prefixed by `tenants/{tenantId}/...`
- **Audit logs** → already exist, add `tenantId`
- **Backups** → standard Postgres `pg_dump` is fine; per-tenant export is a `COPY ... WHERE tenant_id = ...` script
- **Rate limiting** → per-tenant token bucket (e.g. `express-rate-limit` keyed by `req.tenantId`)
- **Logs / metrics** → tag every log line and metric with `tenantId`
- **Vaccine schedules / EPI calendars** → store as a JSON document keyed by code, referenced from `tenants.settings.epiSchedule`
- **Currency formatting** → frontend reads `tenants.settings.currency` from `/api/me/tenant`
- **Map default centre/zoom** → same source
- **Email notifications** → templated per tenant (logo, name, support email)

---

## 10. Phased Roadmap

### Phase 1 — Schema & control plane (1 week)
- Add `tenants`, `tenant_idp_configs`, `population_sources` tables
- Backfill PNG as the first tenant
- Add `tenant_id` to all domain tables (nullable → backfill → NOT NULL)
- Migrate `populationData.source` enum → FK
- CLI: `npm run onboard-tenant`

### Phase 2 — Auth refactor (1–2 weeks)
- Replace Replit Auth with `openid-client` + `passport-saml` dispatcher
- Email-domain → tenant routing on `/login`
- Session payload: `{ userId, tenantId }`
- `requireTenant` middleware
- First-user bootstrap flow

### Phase 3 — Storage & route refactor (1–2 weeks)
- Add `tenantId` parameter to every `IStorage` method
- Update every route to pass `req.ctx`
- Remove any client-supplied `tenantId` from request bodies
- Update frontend to read tenant settings from `/api/me/tenant`
- UI relabelling driven by `tenants.settings.adminLevelLabels`

### Phase 4 — Hardening (1 week)
- Postgres RLS policies on every tenant-scoped table
- Per-request `SET LOCAL app.tenant_id` in a transaction wrapper
- CI lint rule: storage methods must reference `tenantId`
- Cross-tenant penetration tests (Playwright: log in as Tenant A, try to read Tenant B IDs by URL manipulation → must 404/403)

### Phase 5 — Onboarding polish (ongoing)
- Per-tenant branding (logo, primary colour, favicon)
- Per-tenant EPI schedule packs (ZMB_2024, PNG_2023, KEN_2022...)
- Per-tenant CSV importers for facilities and admin hierarchy
- Per-tenant email templates

---

## 11. What You Pay For (Cost Implications)

- **Infra** — same Postgres instance handles 5–20 tenants comfortably. Plan a vertical scale (CPU/RAM) at ~5 tenants and a read replica at ~10.
- **Backups** — single DB backup covers all tenants. Per-tenant export is on-demand.
- **SSO** — no per-tenant cost from your side; the tenant pays for their own IdP licences.
- **Object storage** — pennies per GB; partition by tenant for clean accounting.
- **Engineering** — Phases 1–4 are roughly 4–6 weeks for one engineer. Phase 5 is ongoing as you add countries.

---

## 12. Things You Are Explicitly Not Building (Per Your Decisions)

- ❌ A super-admin UI to manage tenants (you said tenants are sovereign)
- ❌ A user-tenant memberships table (you said one user, one tenant)
- ❌ Subdomain routing (you chose auto-resolve from login)
- ❌ Per-country databases (no data residency requirement)
- ❌ Cross-tenant analytics dashboards
- ❌ A built-in identity provider (every tenant brings their own)

If any of these constraints change later, the data model can absorb them — but skipping them now keeps the v1 scope tight.

---

## 13. Confirmed Operational Policies

| Topic | Decision |
|-------|----------|
| SSO secret storage | External **secret manager** (AWS Secrets Manager / GCP Secret Manager / Vault). DB only stores a reference (`clientSecretRef`). |
| Tenant offboarding | **Soft archive** — `tenants.status = 'archived'`. Data retained, all logins blocked, read-only export available on request. No hard delete. |
| IdP integration testing | Performed by **the developer/platform team**, not the tenant. A staging IdP harness is part of the onboarding kit. |
| User signup model | **Public self-service signup** with **decentralised hierarchical approval** (next section). |

---

## 14. Self-Service Signup with Hierarchical Approval

This is a first-class feature, not a back-office task. The system is decentralised: each level of the hierarchy approves the level immediately below it.

### 14.1 Approval rules

| Requested role | Approved by | Notes |
|----------------|-------------|-------|
| `facility_clerk` | `facility_in_charge` of the same facility (fallback: `district_manager` of that district) | Lowest tier |
| `facility_in_charge` | `district_manager` of the parent district | |
| `district_manager` | `provincial_coordinator` of the parent province | |
| `provincial_coordinator` | `national_admin` | |
| `national_admin` | Existing `national_admin` of the same tenant (fallback: developer/operator via CLI for the very first one) | |
| `gis_specialist` | `national_admin` | Cross-cutting role |

> Rule of thumb: **a request is always approved by the role one level above it in the hierarchy, scoped to the same geographic unit.**

### 14.2 Signup flow

```
1. User visits  /signup  on the tenant's URL (or auto-detected by email domain)
2. They enter:
     - Email (must match a tenant's email_domain)
     - Full name
     - Requested role
     - Province / District / Facility (cascading dropdowns)
     - Justification text (free text)
3. Server creates a row in `signup_requests` with status='pending'
4. Server computes the approver:
     - For facility_clerk → user where role=facility_in_charge AND facilityId=requested.facilityId
     - For facility_in_charge → users where role=district_manager AND districtId=requested.districtId
     - …and so on
5. Server emails the approver(s) with an approval link
6. Approver opens the app → "Pending approvals" inbox → approves or rejects with a reason
7. On approval:
     - users row is created with the requested role + scope
     - The user receives a "your account is ready, sign in via SSO" email
     - On first SSO login, the SSO subject is bound to the users row
8. On rejection:
     - Requester gets the reason via email
     - Request stays in DB for audit
```

### 14.3 New tables

```ts
export const signupStatusEnum = pgEnum("signup_status", [
  "pending",
  "approved",
  "rejected",
  "expired",
]);

export const signupRequests = pgTable("signup_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id").notNull().references(() => tenants.id),
  email: varchar("email", { length: 255 }).notNull(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  requestedRole: userRoleEnum("requested_role").notNull(),
  facilityId: integer("facility_id").references(() => facilities.id),
  districtId: integer("district_id").references(() => districts.id),
  provinceId: integer("province_id").references(() => provinces.id),
  justification: text("justification"),
  status: signupStatusEnum("status").default("pending").notNull(),
  approverUserId: varchar("approver_user_id").references(() => users.id),
  decisionReason: text("decision_reason"),
  decidedAt: timestamp("decided_at"),
  expiresAt: timestamp("expires_at"),                   // auto-expire after 30 days
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => [
  index("idx_signup_tenant_status").on(t.tenantId, t.status),
  index("idx_signup_email").on(t.email),
]);
```

### 14.4 Backend endpoints

```
POST   /api/signup-requests                 (public, rate-limited, no auth)
GET    /api/signup-requests/pending         (auth — returns ones THIS user can approve)
POST   /api/signup-requests/:id/approve     (auth — verifies approver authority)
POST   /api/signup-requests/:id/reject      (auth — verifies approver authority)
GET    /api/signup-requests/me              (auth — for a requester to check status)
```

The "verify approver authority" check is a single helper:

```ts
function canApprove(approver: User, request: SignupRequest): boolean {
  if (approver.tenantId !== request.tenantId) return false;
  switch (request.requestedRole) {
    case "facility_clerk":
      return approver.role === "facility_in_charge"
          && approver.facilityId === request.facilityId;
    case "facility_in_charge":
      return approver.role === "district_manager"
          && approver.districtId === request.districtId;
    case "district_manager":
      return approver.role === "provincial_coordinator"
          && approver.provinceId === request.provinceId;
    case "provincial_coordinator":
    case "gis_specialist":
      return approver.role === "national_admin";
    case "national_admin":
      return approver.role === "national_admin";   // peer approval
  }
}
```

### 14.5 UI additions

- **Public** `/signup` page — cascading dropdowns of provinces/districts/facilities (filtered by tenant, resolved from email domain).
- **In-app "Pending Approvals" inbox** for any user whose role can approve someone (badge in sidebar with count).
- **"My signup status" page** for unauthenticated visitors to check progress with a magic link sent to their email.
- **Notifications** — email on submission, on approval/rejection, and a daily digest to approvers with outstanding requests.

### 14.6 Edge cases & safeguards

- **No approver exists yet.** Example: a district has no `district_manager` when its first `facility_in_charge` applies. Fallback: escalate one level up (request goes to the `provincial_coordinator`). Configurable per tenant.
- **Bootstrapping the first national_admin** is done via the operator CLI at tenant creation (Section 7), so peer approval never deadlocks.
- **Email domain mismatch.** Reject signup at submission if the email domain isn't in any `tenant_idp_configs.emailDomain` for that tenant.
- **Spam/abuse.** Public endpoint is rate-limited per IP and per email; CAPTCHA on the form.
- **Audit trail.** Every approval/rejection writes an `auditLogs` row with approver, requester, decision, reason.
- **Expiry.** Requests auto-expire after 30 days (cron job flips status to `expired`).
- **Re-application.** A user with a `rejected` or `expired` request can re-apply after 7 days.

### 14.7 Decentralisation guarantees

- A `district_manager` in District A **cannot** approve users from District B (enforced by `canApprove`).
- A `provincial_coordinator` in Province X **cannot** see requests outside Province X.
- The platform operator (developer/you) **cannot** approve in-tenant users — only the tenant's own hierarchy can. The only operator-only action is bootstrapping the first `national_admin` per tenant.

---

## 15. Updated Roadmap

### Phase 1 — Schema & control plane (1 week)
- Tenant tables (`tenants`, `tenant_idp_configs`, `population_sources`)
- Signup tables (`signup_requests`, `signup_status` enum)
- Backfill PNG as the first tenant
- Add `tenant_id` to all domain tables
- CLI: `npm run onboard-tenant`

### Phase 2 — Auth refactor with BYO SSO (1–2 weeks)
- `openid-client` + `passport-saml` dispatcher
- Email-domain → tenant routing
- Secret manager integration (no SSO secrets in DB)
- First-`national_admin` bootstrap via CLI

### Phase 3 — Storage & route refactor (1–2 weeks)
- Every storage method takes `tenantId`
- `requireTenant` middleware on all routes
- Frontend reads tenant settings from `/api/me/tenant`

### Phase 4 — Self-service signup & decentralised approval (1 week) ← NEW
- Public `/signup` page with cascading admin pickers
- `canApprove` helper + `/api/signup-requests/*` endpoints
- In-app "Pending Approvals" inbox
- Email notifications + daily approver digest
- Cron job for request expiry

### Phase 5 — Hardening (1 week)
- Postgres RLS policies
- Cross-tenant Playwright pen tests
- Approval-authority bypass tests

### Phase 6 — Onboarding polish (ongoing)
- Per-tenant branding, EPI packs, CSV importers
- Soft-archive / read-only export tooling for offboarded tenants

Total: **~6–8 weeks for one engineer** to reach a full multitenant launch.

---

## 16. What's Now Locked In

- ✅ Shared schema, `tenant_id` everywhere
- ✅ Auto-resolve tenant from logged-in user
- ✅ One user, one tenant
- ✅ Each tenant fully sovereign
- ✅ BYO SSO (OIDC + SAML)
- ✅ Secrets in external secret manager
- ✅ Soft archive on offboarding (no hard delete)
- ✅ Developer-led IdP integration testing
- ✅ Public self-service signup with decentralised hierarchical approval

---

*Companion document to `docs/ZAMBIA_ADAPTATION_GUIDE.md`. Once Phase 1 ships, the Zambia guide becomes "run `npm run onboard-tenant ZMB`."*
