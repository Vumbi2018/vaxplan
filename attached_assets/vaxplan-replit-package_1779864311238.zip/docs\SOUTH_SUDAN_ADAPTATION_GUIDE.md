# South Sudan (SSD) Adaptation Guide

Adapting the VaxPlan GIS Microplanning platform for the **Republic of South Sudan Ministry of Health**, with specific configuration for the WHO EPI programme, South Sudan's unique administrative hierarchy, and HIS interoperability with DHIS2 and eHIS.

---

## 1. Country Overview

| Parameter | Value | Source |
|-----------|-------|--------|
| Official name | Republic of South Sudan | |
| ISO-3166 Alpha-3 | **SSD** | |
| Capital | Juba | |
| Population (2023 est.) | ~11.5 million | UNICEF/UN DESA |
| Annual birth rate | ~4.2% (CBR 42/1,000) | WHO GHO 2023 |
| Under-5 mortality | 98/1,000 (one of highest globally) | UNICEF 2022 |
| MMR | 1,150/100,000 live births | WHO 2020 |
| EPI coverage | BCG 58%, Penta3 56% (2022) | UNICEF JRF |
| Currency | South Sudanese Pound (SSP) | |
| Languages | English (official), Arabic, Nuer, Dinka, Zande | |
| DHIS2 instance | https://dhis2.moh.gov.ss (Ministry HMIS) | |
| HIS standard | DHIS2 + eHIS (national systems) | |

South Sudan is one of the world's newest nations (independence 2011) and faces acute health system challenges:
- Extremely limited health infrastructure — only 1 doctor per ~65,000 people
- Large internally displaced population (IDP camps require mobile EPI teams)
- High proportion of hard-to-reach populations (HTR is critical workflow)
- Fragile supply chain — VVM monitoring is mandatory for cold chain verification

---

## 2. Administrative Hierarchy

South Sudan uses a 4-level hierarchy (replaces PNG LLG / Zambia Ward):

| VaxPlan Level | SSD Name | Count | Notes |
|---------------|----------|-------|-------|
| Level 1 (Region) | **State** | 10 | Legislative boundary; some sources also reference 32 states under a 2015–2020 partition (currently reverted to 10) |
| Level 2 (Province) | **County** | 78 | Primary health administration unit |
| Level 3 (District) | **Payam** | ~587 | Sub-county unit; primary microplanning unit |
| Level 4 (Ward) | **Boma** | ~2,500 | Village-cluster / CHW catchment area |

### 2.1 VaxPlan `tenants.settings.adminLevelLabels`

```jsonc
{
  "adminLevelLabels": {
    "level1": "State",
    "level2": "County",
    "level3": "Payam",
    "level4": "Boma"
  }
}
```

### 2.2 The 10 States

```ts
const SSD_STATES = [
  { name: "Central Equatoria", code: "CE", capital: "Juba" },
  { name: "Eastern Equatoria",  code: "EE", capital: "Torit" },
  { name: "Western Equatoria", code: "WE", capital: "Yambio" },
  { name: "Jonglei",            code: "JG", capital: "Bor" },
  { name: "Unity",              code: "UN", capital: "Bentiu" },
  { name: "Upper Nile",         code: "UL", capital: "Malakal" },
  { name: "Lakes",              code: "LK", capital: "Rumbek" },
  { name: "Warrap",             code: "WR", capital: "Kwajok" },
  { name: "Western Bahr el Ghazal", code: "WB", capital: "Wau" },
  { name: "Northern Bahr el Ghazal", code: "NB", capital: "Aweil" },
];
```

> **Source**: OCHA South Sudan admin boundary (COD-AB), SSNIS 2023. Always verify against the current NBS/SSNIS gazetteer — administrative reorganisation is ongoing.

---

## 3. Demographic Ratios (WHO Settings)

From WHO/UNICEF Global Health Observatory 2023 and SSNIS:

```ts
settings.demographics = {
  births:      0.042,  // 4.2% — one of world's highest crude birth rates
  under1:      0.040,  // 4.0% under-1 cohort
  pregnant:    0.045,  // 4.5% — high MMR makes this priority target group
  schoolEntry: 0.036,  // school-entry (6yr) — low net enrollment rate (NER ~40%)
  schoolExit:  0.030,  // school-exit (12yr)
};
```

Use `MICS 2022` or `SSNIS Survey` data for district-level calibration.

---

## 4. EPI Schedule (SSD_2024)

South Sudan EPI schedule aligned with WHO recommendations (SSPHC / UNICEF 2024):

| Age | Vaccine | Doses | VaxPlan Code |
|-----|---------|-------|--------------|
| Birth | BCG | 1 | `BCG` |
| Birth | OPV-0 | 1 | `OPV0` |
| 6 weeks | Penta 1 + OPV 1 + PCV 1 | 3 | `PENTA1`, `OPV1`, `PCV1` |
| 10 weeks | Penta 2 + OPV 2 + PCV 2 | 3 | `PENTA2`, `OPV2`, `PCV2` |
| 14 weeks | Penta 3 + OPV 3 + PCV 3 + IPV | 4 | `PENTA3`, `OPV3`, `PCV3`, `IPV` |
| 9 months | MR 1 | 1 | `MR1` |
| 15 months | MR 2 | 1 | `MR2` |
| 9–14 years | HPV 1 & 2 (girls) | 2 | `HPV1`, `HPV2` |
| Women 15–49 | TT 1–5 | 5 series | `TT1`–`TT5` |

> **VVM Priority**: All vaccines in SSD require VVM stage monitoring due to solar direct-drive fridge variability and frequent stockouts. Enable VVM tracking in `StockLedger`.

---

## 5. Map Configuration

```jsonc
{
  "mapCenter": [7.87, 29.69],
  "mapZoom": 6,
  "defaultBoundaryLevel": 1
}
```

Replace Leaflet `MapContainer` default props with the above values. The GeoBoundaries service already has SSD at ADM1–ADM3 (State → County → Payam).

---

## 6. Currency & Financial

```jsonc
{
  "currency": "SSP",
  "currencySymbol": "£",
  "fiscalYearStart": "01-01"
}
```

> Budget planning in VaxPlan stores values as decimal numbers — just relabel currency in UI. Hyperinflation context: consider also supporting USD in budget reporting for donor-funded activities.

---

## 7. Population Data Sources

South Sudan has no complete modern census (2008 census was the last). Use layered estimates:

| VaxPlan Source Code | Label | Use |
|--------------------|-------|-----|
| `nbs` | NBS Census (2008 projected) | Baseline official estimate |
| `unicef` | UNICEF / WHO Estimates | Annual child population estimates |
| `worldpop` | WorldPop Gridded | High-resolution gridded population |
| `survey` | MICS / SMART Survey | District-level nutritional / child mortality surveys |
| `community_census` | Community CHW Census | CHW-enumerated household counts |

These are pre-configured in the SSD tenant `populationSources` settings via the self-healing bootstrap.

---

## 8. HIS Interoperability

### 8.1 DHIS2 South Sudan

| Parameter | Value |
|-----------|-------|
| DHIS2 URL | `https://dhis2.moh.gov.ss` |
| Version | DHIS2 2.40+ |
| Auth | Bearer token (personal access token) |
| Data set | MOH EPI Immunization Monthly Report |
| Org unit root | Country level UID (get from `/api/organisationUnits?level=1`) |

**Environment variables required**:
```bash
HIS_DHIS2_SSD_TOKEN=<personal-access-token-from-dhis2-account>
HIS_DHIS2_SSD_URL=https://dhis2.moh.gov.ss
```

**Integration config in `tenants.settings.hisIntegrations`**:
```json
[
  {
    "id": "dhis2-ssd-primary",
    "type": "dhis2",
    "label": "South Sudan MOH DHIS2",
    "baseUrl": "https://dhis2.moh.gov.ss",
    "secretRef": "HIS_DHIS2_SSD_TOKEN",
    "enabled": true,
    "dhis2RootOrgUnit": "<country-org-unit-uid>",
    "dhis2DataSetUid": "<epi-dataset-uid>"
  }
]
```

Then map DHIS2 data element UIDs per vaccine (get from DHIS2 `/api/dataElements`):
```bash
DHIS2_DE_BCG_UID=AbCdEfGhIjK
DHIS2_DE_OPV0_UID=LmNoPqRsTuV
# ... etc for each vaccine code
```

### 8.2 South Sudan eHIS (Generic REST)

South Sudan's eHIS system accepts a custom REST payload for immunization data:
```json
{
  "id": "ehis-ssd",
  "type": "hmis_generic",
  "label": "South Sudan eHIS",
  "baseUrl": "https://ehis.moh.gov.ss/api/v1/immunizations",
  "secretRef": "HIS_HMIS_SSD_TOKEN",
  "enabled": true
}
```

### 8.3 HL7 FHIR R4 (OpenMRS)

If the MOH deploys OpenMRS with the FHIR module:
```json
{
  "id": "fhir-ssd-openmrs",
  "type": "fhir_r4",
  "label": "South Sudan OpenMRS FHIR",
  "baseUrl": "https://openmrs.moh.gov.ss",
  "fhirBaseUrl": "https://openmrs.moh.gov.ss/openmrs/ws/fhir2/R4",
  "secretRef": "HIS_FHIR_SSD_TOKEN",
  "enabled": true
}
```

---

## 9. Hard-to-Reach (HTR) Configuration

HTR is especially critical for South Sudan. Configure:
- **Transport modes**: foot, motorbike, 4WD, boat (Sudd swamp region — Jonglei State), helicopter (humanitarian operations)
- **HTR score threshold**: recommend ≥ 2 for HTR classification (vs standard ≥ 3) given generalised inaccessibility
- **IDP camps**: classify as `special_population` site type in Session Planning

---

## 10. Step-by-Step Onboarding Checklist

### Platform side (developer / operator)
- [x] SSD tenant registered via Country Onboarding page (`code: SSD`, `countryCode: SSD`)
- [x] Self-healing bootstrap stamps demographics, admin level labels, and map settings automatically on next server start
- [ ] Set env vars: `HIS_DHIS2_SSD_TOKEN`, `HIS_DHIS2_SSD_URL`, `HIS_HMIS_SSD_TOKEN` (if applicable)
- [ ] Add `hisIntegrations` array to SSD tenant settings via `PATCH /api/me/tenant`
- [ ] Seed 10 States via `POST /api/regions` (as regions)
- [ ] Seed 78 Counties via `POST /api/provinces` (as provinces)
- [ ] Import OCHA COD-AB boundary GeoJSON via BoundaryManager page
- [ ] Import Master Facility List from MOH/WHO SSD health facility registry
- [ ] Set DHIS2 org unit UIDs on each facility via facility management page

### MOH in-country setup (national_admin)
- [ ] First login: developer upgrades first user to `national_admin` via CLI:
  ```sql
  UPDATE users SET role = 'national_admin' WHERE email = 'admin@moh.gov.ss';
  ```
- [ ] national_admin creates provincial coordinators for 10 states
- [ ] Verify map centres on Juba (`7.87°N, 31.63°E`)
- [ ] Configure vaccine configuration records for SSD_2024 schedule
- [ ] Test push to DHIS2 via HIS Integrations page (select any monthly report → push)

---

## 11. Useful References

- OCHA South Sudan COD-AB: https://data.humdata.org/dataset/cod-ab-ssd
- South Sudan NBS: https://nbs.gov.ss
- WHO South Sudan HMIS: https://extranet.who.int/countryplanningcycles/node/50
- UNICEF South Sudan: https://www.unicef.org/southsudan/
- WorldPop SSD: https://www.worldpop.org/geodata/listing?id=69
- MICS 2022 Report: https://mics.unicef.org/surveys

---

*Generated as a South Sudan adaptation guide for the VaxPlan GIS Microplanning platform. Companion to `docs/ZAMBIA_ADAPTATION_GUIDE.md` and `docs/MULTITENANT_ARCHITECTURE.md`.*
