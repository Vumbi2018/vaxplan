# VaxPlan Offline Architecture

## Overview

VaxPlan is an **offline-first** application. All core workflows function fully without internet connectivity. When connectivity is restored, data is automatically synchronized to the central PostgreSQL server.

This architecture supports three deployment targets sharing the same React codebase:

| Target | Technology | Use Case |
|--------|-----------|----------|
| **Browser PWA** | Vite + Workbox Service Worker | Any device with a modern browser |
| **Android APK** | Capacitor (wraps the PWA) | Field workers / community health workers |
| **Windows App** | Electron (loads hosted server URL) | District-level PCs and laptops |

---

## Offline Data Flow

```
User Action (offline)
    │
    ▼
React Component
    │  mutation fails (offline) OR succeeds (online)
    ▼
offlineDb.ts (Dexie/IndexedDB)      ◄── stores data locally
    │
    ▼
outbox table (pending mutations)    ◄── queues for later replay
    │
    │  when online
    ▼
syncEngine.ts → flush()
    │
    ├── POST /api/sync/batch  ──────►  Express server
    │                                       │
    │                                       ▼
    │                                  PostgreSQL
    │
    └── GET /api/sync/pull   ◄───────  Delta of server changes
    │
    ▼
IndexedDB updated with server data
```

---

## Components

### `client/src/lib/offlineDb.ts`
Dexie.js IndexedDB schema. Every server table has a local mirror:
- `clients`, `clientVaccinations` — EPI records
- `facilities`, `villages`, `regions`, `provinces`, `districts`
- `sessionPlans`, `stockTransactions`, `monthlyReports`
- `populationData`, `vaccineConfigs`

Control tables:
- **`outbox`** — mutation queue (method + URL + body + retries)
- **`conflictLog`** — records overwritten during conflict resolution
- **`syncMeta`** — `lastSyncAt` timestamp

### `client/src/lib/syncEngine.ts`
Singleton sync engine:
- `flush()` — drains outbox to server
- `pull()` — fetches delta from server since `lastSyncAt`
- `sync()` — flush + pull
- Auto-triggers on `window.online` event and every 5 minutes

### `client/src/hooks/useNetworkStatus.ts`
Reacts to `online`/`offline` events + Network Information API:
- `isOnline` — true/false
- `isSlowConnection` — true if 2G/slow-2G
- `connectionType` — wifi / cellular / ethernet
- `effectiveType` — slow-2g / 2g / 3g / 4g

### `client/src/hooks/useSyncEngine.ts`
React bridge to the sync engine singleton. Initializes with the authenticated user's `tenantId`.

### `client/src/components/OfflineBanner.tsx`
Status bar mounted at the top of every authenticated page:
- Hides when online and fully synced
- Shows pending count badge + "Sync Now" button
- Shows connection type (WiFi / Cellular)
- Shows last sync timestamp

### `server/services/syncService.ts`
Server-side sync logic:
- `pullChanges(tenantId, since)` — returns all records WHERE `updatedAt > since`
- `batchMutate(tenantId, mutations[], userId)` — applies each mutation, returns success/fail per item
- `getSyncStats(tenantId)` — record counts for all tables

### Sync API Routes
```
GET  /api/sync/pull?since=<ISO>   — delta pull (or full replica if no since)
POST /api/sync/batch              — push outbox mutations
GET  /api/sync/status             — record counts
```

---

## Service Worker (PWA)

Configured via `vite-plugin-pwa` with Workbox. Cache strategies:

| Resource | Strategy | Duration |
|----------|----------|---------|
| App shell (JS/CSS/HTML) | CacheFirst | Indefinite (bust on build hash) |
| `/api/*` GET | NetworkFirst | 5s timeout → serve cache |
| Map tiles (OSM/Carto) | CacheFirst | 30 days, max 1500 tiles |
| Google Fonts | StaleWhileRevalidate | Long-lived |
| `/api/sync/*` | NetworkOnly | Always live |

---

## Android Build (Capacitor)

### Prerequisites
- Node.js 20+
- Java 17+ (JDK) — [Adoptium](https://adoptium.net)
- Android Studio + Android SDK API 34
- `ANDROID_HOME` environment variable set

### Debug APK
```powershell
npm run build:android
# Output: android/app/build/outputs/apk/debug/app-debug.apk
```

### Release APK (signed for distribution)
```powershell
npm run build:android:release
# Prompts for keystore password
# Output: android/app/build/outputs/apk/release/app-release.apk
```

### Open in Android Studio
```powershell
npm run cap:open:android
```

### Sync after code changes
```powershell
npm run cap:sync
```

### Android Specifications
- Min SDK: **26** (Android 8.0 Oreo)
- Target SDK: **34** (Android 14)
- Architecture: arm64-v8a + x86_64
- App ID: `io.vaxplan.health`

---

## Windows Build (Electron)

### Prerequisites
- Node.js 20+
- Windows 10/11 (64-bit)

### Build installer
```powershell
npm run build:windows
# Output: out/make/squirrel.windows/x64/VaxPlanSetup.exe
```

### Dev mode (Electron + Vite HMR)
```powershell
npm run electron:dev
```

### Architecture
- Electron loads the hosted server URL (Option A)
- Service Worker provides offline capability
- System tray with "Sync Now" shortcut
- Auto-updater via `electron-updater`
- Deep link: `vaxplan://sync` triggers sync from anywhere

---

## Conflict Resolution

**Strategy: Last-Writer-Wins (LWW) with conflict logging**

When two devices edit the same record offline:
1. First device to sync wins (server timestamp `updatedAt` used as version)
2. The losing version is written to the `conflictLog` table
3. Conflicts are visible to `national_admin` in the audit log

Future enhancement: per-entity configurable resolution (LWW vs manual review).

---

## Sync Scope

**Full national replica** — the tenant's entire dataset is synced to each device.

- Initial sync (no `since`): downloads all records (~50–500 MB depending on tenant size)
- Subsequent syncs (delta): only records with `updatedAt > lastSyncAt`
- Recommended: initial sync on WiFi, subsequent syncs on any connection

> For very large tenants (>100k clients), consider scoping sync to the user's district by filtering the pull query. The `syncService.ts` pull query currently returns all tenant data; add a `WHERE districtId = ?` filter to scope it.

---

## Security

- `tenantId` in each batch mutation is **always overridden** by the server's authenticated session — never trusted from client payload
- All sync routes require `isAuthenticated + requireTenant` middleware
- Outbox items are stored in browser IndexedDB — cleared on app uninstall
- No credentials are stored in IndexedDB; sessions use secure HttpOnly cookies

---

*See also: [SOUTH_SUDAN_ADAPTATION_GUIDE.md](./SOUTH_SUDAN_ADAPTATION_GUIDE.md) | [ZAMBIA_ADAPTATION_GUIDE.md](./ZAMBIA_ADAPTATION_GUIDE.md)*
